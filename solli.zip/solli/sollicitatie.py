print('----------------------------------------------')
print('Welkom bij de:\nCircusdirecteur voor Circus HotelDeBotel Vacature')
print('----------------------------------------------')
print('Laten we beginnen!')


#NAAM EN LEEFTIJD
Naam = (input('Wat is uw voor en achternaam? '))
Leeftijd = (input('Wat is uw leeftijd? '))
#NAAM EN LEEFTIJD 

#PRAKTIJK ERVARING CODE
PraktijkErvaring = (input('Hoeveel jaar praktijk ervaring heeft u met Dieren-Dressuur?'))
if int(PraktijkErvaring) >=4:
    Diploma = (input('Bent u in bezit van een Diploma MBO-4 ondernemen? (ja/nee) '))
else:
    PraktijkErvaring2 = (input('Hoeveel jaar ervaring heeft u met jongleren?'))
    if int(PraktijkErvaring2) >=5:
        Diploma = (input('Bent u in bezit van een Diploma MBO-4 ondernemen? (ja/nee) '))
    else:
        PraktijkErvaring3 = (input('Hoevel jaar praktijk ervaring heeft u met acrobatiek?'))
        if int(PraktijkErvaring3) >=3:
            Diploma = (input('Bent u in bezit van een Diploma MBO-4 ondernemen? (ja/nee) '))
        else:
            print("------------------------------------------------------------------------------------")
            print("Sorry! Aangezien u niet genoeg Praktijk ervaring heeft kunt u niet bij ons komen werken.")
            print("------------------------------------------------------------------------------------")
#PRAKTIJK ERVARING CODE

#DIPLOMA CODE
if Diploma == "ja":
    Rijbewijs = (input('Bent u in bezit van een geldig Vrachtwagen rijbewijs(ja/nee) '))
else: 
    Rijbewijs = (input('Bent u in bezit van een geldig Vrachtwagen rijbewijs(ja/nee) '))
#DIPLOMA CODE

#RIJBEWIJS CODE
if Rijbewijs == "ja":
    HogeHoed = (input('Bent u in bezit van een hoge hoed? '))
else: 
    HogeHoed = (input('Bent u in bezit van een hoge hoed? '))  
#RIJBEWIJS CODE

#HOGEHOED CODE
if HogeHoed == "ja":
    ManVraag = (input('Bent u een (Man/Vrouw) '))
else:
    ManVraag = (input('Bent u een (Man/Vrouw) '))
#HOGEHOED CODE

#MANVRAAG VROUWVRAAG CODE
if ManVraag == "Man":
    SnorVraag = (input('Hoe breed is uw snor?'))
else: 
    KrulhaarVraag = (input('Heeft u Rood krulhaar dat langer is dan 20 centimeter?'))
#MANVRAAG VROUWVRAAG CODE

#SNORVRAAG ALS HET MAN IS
if int(SnorVraag) >= 10:
    Lengte = (input('Wat is uw lengte? '))
else:
    Lengte = (input('Wat is uw lengte? '))
#SNORVRAAG ALS HET MAN IS

#KRULHAARVRAAG ALS HET VROUW IS
if KrulhaarVraag == "ja":
    Lengte = (input('Wat is uw lengte?'))
else:
    Lengte = (input('Wat is uw lengte?'))
#KRULHAARVRAAG ALS HET VROUW IS

#LENGTE VRAAG
if int(Lengte) >= 150:
    GewichtVraag = input('Hoeveel weegt u?')
else:
    GewichtVraag = input('Hoeveel weegt u?')
#LENGTE VRAAG 

#GEWICHT VRAAG
if int(GewichtVraag) >= 90:
    CertificaatVraag = input('Heeft Certificaat “Overleven met gevaarlijk personeel”')
else:
    CertificaatVraag = input('Heeft Certificaat “Overleven met gevaarlijk personeel”')
#GEWICHT VRAAG
    print('Gefeliciteerd u bent aangenomen!')




    